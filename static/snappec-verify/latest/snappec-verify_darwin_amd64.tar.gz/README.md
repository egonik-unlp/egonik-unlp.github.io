# snappec-verify

Verifica que lo que una spec afirma se sostenga en el sistema real. Convierte la spec en un **contrato
ratificado** de invariantes y corre cinco prongs (property, bank de edge cases, estático, sandbox, volumen y
concurrencia) que intentan romperlo. *Los agentes proponen, el código decide, las personas ratifican.*

```sh
CGO_ENABLED=0 go install ./cmd/snappec-verify     # desde este checkout
cd <tu-proyecto> && snappec-verify init           # o init --snappec para Claude Code
```

- **Manual de instalación y uso:** [docs/manual.md](docs/manual.md)
- Protocolo de adapters: [adapters/PROTOCOL.md](adapters/PROTOCOL.md) · adapter de Ruby/Rails:
  [adapters/ruby/README.md](adapters/ruby/README.md)
- Diseño: [openspec/changes/add-snappec-verify/](openspec/changes/add-snappec-verify/)

| Directorio | Qué hay |
|---|---|
| `cmd/snappec-verify` | el CLI |
| `internal/` | el core: estado, contrato, oráculo CEL, prongs, records, baseline, ledger, bank, sandbox, hook |
| `adapters/ruby` | la gem `snappec-verify-ruby` (Ruby ≥ 2.7) |
| `templates/` | lo que instala `init` (`standalone/` y `snappec/`) |
| `testdata/` | fixtures, golden files y la app Rails de prueba |
